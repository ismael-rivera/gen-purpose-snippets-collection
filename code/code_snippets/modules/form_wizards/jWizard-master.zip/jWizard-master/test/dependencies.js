window.versions = {
    jquery: "1.9.1",
    jqueryui: "1.10.1"
};

<?php

// Load up our awesome theme options
require_once ( get_stylesheet_directory() . '/theme-options.php' );
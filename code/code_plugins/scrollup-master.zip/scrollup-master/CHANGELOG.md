# Changelog

## 1.1
- Add option for using images (with example)
- Code Optimisations
- Update jQuery to 1.9.1

## 1.0
- Release
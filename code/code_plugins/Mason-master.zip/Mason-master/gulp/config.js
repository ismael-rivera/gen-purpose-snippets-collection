var path = require('path');

module.exports = {
  'port': '4000',
  'root': path.resolve('./public')
};
